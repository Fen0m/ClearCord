# Discord Themes
This repo is for where I put the (mini) themes I make for Discord.
